
from django import forms
from .models import Viaje, Documento
from datetime import date, datetime

class ViajeForm(forms.ModelForm):
    rut_trabajador = forms.CharField(label="RUT Conductor")
    nombre_trabajador = forms.CharField(label="Nombre Conductor", required=False)
    class Meta:
        model = Viaje
        fields = ['codigo','origen','destino','patente_camion','fecha_salida','hora_salida','rut_trabajador','nombre_trabajador']
        widgets = {
            'fecha_salida': forms.DateInput(attrs={'type':'date'}),
            'hora_salida': forms.TimeInput(attrs={'type':'time'}),
            'origen': forms.TextInput(attrs={'placeholder':'Ej: Rengo'}),
            'destino': forms.TextInput(attrs={'placeholder':'Ej: Puerto Montt'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['fecha_salida'].initial = date.today()
        self.fields['hora_salida'].initial = datetime.now().strftime('%H:%M')

class DocumentoForm(forms.ModelForm):
    class Meta:
        model = Documento
        fields = ['tipo_documento','monto','plaza_peaje','numero_documento','fecha_cruce','hora_cruce','imagen']
        widgets = {
            'fecha_cruce': forms.DateInput(attrs={'type':'date'}),
            'hora_cruce': forms.TimeInput(attrs={'type':'time'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['fecha_cruce'].initial = date.today()
        self.fields['hora_cruce'].initial = datetime.now().strftime('%H:%M')
