
from django.urls import path
from . import views
urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('viaje/nuevo/', views.crear_viaje, name='crear_viaje'),
    path('viaje/<int:viaje_id>/', views.detalle_viaje, name='detalle_viaje'),
    path('viaje/<int:viaje_id>/finalizar/', views.finalizar_viaje, name='finalizar_viaje'),
    path('exportar/', views.exportar_excel, name='exportar'),
]
