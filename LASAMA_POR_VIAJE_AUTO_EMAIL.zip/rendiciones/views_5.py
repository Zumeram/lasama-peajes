
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .forms import ViajeForm, DocumentoForm
from .models import Trabajador, Viaje, Documento
import pandas as pd
from datetime import datetime
from django.db import IntegrityError

def inicio(request):
    viajes = Viaje.objects.all().order_by('-fecha_creacion')[:10]
    return render(request, 'rendiciones/inicio_viaje.html', {'viajes': viajes})

def crear_viaje(request):
    if request.method == 'POST':
        form = ViajeForm(request.POST)
        if form.is_valid():
            rut = form.cleaned_data['rut_trabajador'].strip()
            nombre = form.cleaned_data['nombre_trabajador'] or 'Conductor LASAMA'
            trabajador, _ = Trabajador.objects.get_or_create(rut=rut, defaults={'nombre': nombre})
            viaje = form.save(commit=False)
            viaje.trabajador = trabajador
            viaje.save()
            return redirect('detalle_viaje', viaje_id=viaje.id)
    else:
        form = ViajeForm()
    return render(request, 'rendiciones/crear_viaje.html', {'form': form})

def detalle_viaje(request, viaje_id):
    viaje = get_object_or_404(Viaje, id=viaje_id)
    if request.method == 'POST':
        form = DocumentoForm(request.POST, request.FILES)
        if form.is_valid():
            doc = form.save(commit=False)
            doc.viaje = viaje
            try:
                doc.save()
                return redirect('detalle_viaje', viaje_id=viaje.id)
            except IntegrityError:
                form.add_error('imagen','Peaje duplicado en este viaje LASAMA')
    else:
        form = DocumentoForm()
    return render(request, 'rendiciones/detalle_viaje.html', {'viaje': viaje, 'form': form, 'peajes': viaje.documentos.all()})

def exportar_excel(request):
    qs = Documento.objects.select_related('viaje','viaje__trabajador').all()
    data = []
    for d in qs:
        data.append({
            'N° Viaje': d.viaje.codigo,
            'Empresa': 'LASAMA',
            'Origen': d.viaje.origen,
            'Destino': d.viaje.destino,
            'Patente': d.viaje.patente_camion,
            'Conductor': d.viaje.trabajador.nombre,
            'RUT': d.viaje.trabajador.rut,
            'Tipo Peaje': d.tipo_documento,
            'Plaza/Barcaza': d.plaza_peaje,
            'Monto': d.monto,
            'N° Boleta': d.numero_documento,
            'Fecha Cruce': str(d.fecha_cruce),
            'Hora Cruce': str(d.hora_cruce),
            'Estado Viaje': d.viaje.estado,
        })
    df = pd.DataFrame(data)
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename=LASAMA_VIAJES_{datetime.now().date()}.xlsx'
    df.to_excel(response, index=False)
    return response

def finalizar_viaje(request, viaje_id):
    viaje = get_object_or_404(Viaje, id=viaje_id)
    viaje.estado = 'Finalizado'
    viaje.save()
    return redirect('detalle_viaje', viaje_id=viaje.id)
