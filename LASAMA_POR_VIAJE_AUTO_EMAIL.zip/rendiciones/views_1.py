
from django.shortcuts import render
from django.http import HttpResponse
from .forms import DocumentoForm
from .models import Trabajador, Documento
import pandas as pd
from datetime import datetime
from django.db import IntegrityError

def inicio(request):
    if request.method == 'POST':
        form = DocumentoForm(request.POST, request.FILES)
        if form.is_valid():
            rut = form.cleaned_data['rut_trabajador'].strip()
            nombre = form.cleaned_data['nombre_trabajador'] or 'Trabajador LASAMA'
            trabajador, _ = Trabajador.objects.get_or_create(rut=rut, defaults={'nombre': nombre})
            if nombre != 'Trabajador LASAMA':
                trabajador.nombre = nombre
                trabajador.save()
            doc = form.save(commit=False)
            doc.trabajador = trabajador
            # patente ya viene en form
            try:
                doc.save()
                return render(request, 'rendiciones/exito.html', {'doc': doc})
            except IntegrityError:
                form.add_error('imagen', '¡Documento duplicado! Esta imagen ya existe en LASAMA.')
    else:
        form = DocumentoForm()
    return render(request, 'rendiciones/subir.html', {'form': form})

def exportar_excel(request):
    qs = Documento.objects.select_related('trabajador').all()
    data = []
    for d in qs:
        data.append({
            'Empresa': 'LASAMA',
            'Nombre Trabajador': d.trabajador.nombre,
            'RUT Trabajador': d.trabajador.rut,
            'Patente Camion': d.patente_camion,
            'Tipo Documento': d.tipo,
            'N° Documento': d.numero_documento,
            'Monto $': d.monto,
            'Lugar': d.lugar,
            'Fecha Gasto': str(d.fecha_ingreso),
            'Hora Gasto': str(d.hora_ingreso),
            'Dia Semana': d.fecha_ingreso.strftime('%A'),
            'Fecha Registro Sistema': str(d.fecha_registro_sistema),
            'Hash Imagen': d.hash_imagen,
        })
    df = pd.DataFrame(data)
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename=LASAMA_planilla_{datetime.now().date()}.xlsx'
    df.to_excel(response, index=False)
    return response
