
from django.urls import path
from . import views
urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('exportar/', views.exportar_excel, name='exportar'),
]
