
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.core.mail import EmailMessage
from django.conf import settings
from .forms import ViajeForm, DocumentoForm
from .models import Trabajador, Viaje, Documento
import pandas as pd
from datetime import datetime
from django.db import IntegrityError
import io
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

def inicio(request):
    viajes = Viaje.objects.all().order_by('-fecha_creacion')[:10]
    return render(request, 'rendiciones/inicio_viaje.html', {'viajes': viajes})

def crear_viaje(request):
    if request.method == 'POST':
        form = ViajeForm(request.POST)
        if form.is_valid():
            rut = form.cleaned_data['rut_trabajador'].strip()
            nombre = form.cleaned_data['nombre_trabajador'] or 'Conductor LASAMA'
            trabajador, _ = Trabajador.objects.get_or_create(rut=rut, defaults={'nombre': nombre})
            if nombre != 'Conductor LASAMA':
                trabajador.nombre = nombre
                trabajador.save()
            viaje = form.save(commit=False)
            viaje.trabajador = trabajador
            viaje.save()
            return redirect('detalle_viaje', viaje_id=viaje.id)
    else:
        form = ViajeForm()
    return render(request, 'rendiciones/crear_viaje.html', {'form': form})

def detalle_viaje(request, viaje_id):
    viaje = get_object_or_404(Viaje, id=viaje_id)
    if request.method == 'POST':
        form = DocumentoForm(request.POST, request.FILES)
        if form.is_valid():
            doc = form.save(commit=False)
            doc.viaje = viaje
            try:
                doc.save()
                return redirect('detalle_viaje', viaje_id=viaje.id)
            except IntegrityError:
                form.add_error('imagen','Peaje duplicado en este viaje LASAMA')
    else:
        form = DocumentoForm()
    return render(request, 'rendiciones/detalle_viaje.html', {'viaje': viaje, 'form': form, 'peajes': viaje.documentos.all()})

def generar_excel_viaje(viaje):
    data = []
    for d in viaje.documentos.all():
        data.append({
            'N° Viaje': viaje.codigo,
            'Empresa': 'LASAMA',
            'Origen': viaje.origen,
            'Destino': viaje.destino,
            'Patente': viaje.patente_camion,
            'Conductor': viaje.trabajador.nombre,
            'RUT': viaje.trabajador.rut,
            'Tipo Peaje': d.tipo_documento,
            'Plaza/Barcaza': d.plaza_peaje,
            'Monto': d.monto,
            'N° Boleta': d.numero_documento,
            'Fecha Cruce': str(d.fecha_cruce),
            'Hora Cruce': str(d.hora_cruce),
        })
    df = pd.DataFrame(data)
    output = io.BytesIO()
    df.to_excel(output, index=False)
    output.seek(0)
    return output

def generar_pdf_viaje(viaje):
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    c.setFont("Helvetica-Bold", 16)
    c.drawString(40, height-50, f"LASAMA - Rendición Viaje {viaje.codigo}")
    c.setFont("Helvetica", 11)
    c.drawString(40, height-70, f"{viaje.origen} -> {viaje.destino} | Patente: {viaje.patente_camion} | Conductor: {viaje.trabajador.nombre} ({viaje.trabajador.rut})")
    c.drawString(40, height-85, f"Fecha Salida: {viaje.fecha_salida} {viaje.hora_salida} | Total Peajes: ${viaje.total_peajes} ({viaje.cantidad_peajes} boletas)")
    y = height - 120
    for doc in viaje.documentos.all():
        if y < 250:
            c.showPage()
            y = height - 50
        c.setFont("Helvetica-Bold", 11)
        c.drawString(40, y, f"{doc.tipo_documento} - {doc.plaza_peaje} - ${doc.monto} - {doc.fecha_cruce} {doc.hora_cruce}")
        y -= 15
        c.setFont("Helvetica", 9)
        c.drawString(40, y, f"N° Boleta: {doc.numero_documento}")
        y -= 10
        try:
            if doc.imagen:
                img = ImageReader(doc.imagen.path if hasattr(doc.imagen, 'path') else doc.imagen)
                c.drawImage(img, 40, y-150, width=200, height=140, preserveAspectRatio=True)
                y -= 160
            else:
                y -= 20
        except Exception as e:
            c.drawString(40, y, f"[Imagen no disponible: {e}]")
            y -= 20
    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer

def finalizar_viaje(request, viaje_id):
    viaje = get_object_or_404(Viaje, id=viaje_id)
    viaje.estado = 'Finalizado'
    viaje.save()

    # Generar archivos
    excel_file = generar_excel_viaje(viaje)
    pdf_file = generar_pdf_viaje(viaje)

    # Enviar correo a Finanzas
    try:
        email = EmailMessage(
            subject=f"[LASAMA] Viaje Finalizado {viaje.codigo} - {viaje.patente_camion} - ${viaje.total_peajes}",
            body=f"""
Hola Finanzas LASAMA,

El conductor {viaje.trabajador.nombre} ({viaje.trabajador.rut}) ha finalizado el viaje:

- Código: {viaje.codigo}
- Ruta: {viaje.origen} -> {viaje.destino}
- Patente: {viaje.patente_camion}
- Fecha: {viaje.fecha_salida}
- Total Peajes: ${viaje.total_peajes}
- Cantidad Boletas: {viaje.cantidad_peajes}

Adjunto Excel y PDF con todas las fotos de boletas de peajes troncales y barcazas.

Saludos,
Sistema LASAMA
            """,
            from_email=settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'lasama@sistema.cl',
            to=['finanzas@lasama.cl'],  # CAMBIAR POR CORREO REAL DE FINANZAS
        )
        email.attach(f'{viaje.codigo}.xlsx', excel_file.read(), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        email.attach(f'{viaje.codigo}.pdf', pdf_file.read(), 'application/pdf')
        email.send(fail_silently=True)
    except Exception as e:
        print(f"Error enviando correo: {e}")

    return render(request, 'rendiciones/viaje_finalizado.html', {'viaje': viaje})

def exportar_excel(request):
    qs = Documento.objects.select_related('viaje','viaje__trabajador').all()
    data = []
    for d in qs:
        data.append({
            'N° Viaje': d.viaje.codigo,
            'Empresa': 'LASAMA',
            'Origen': d.viaje.origen,
            'Destino': d.viaje.destino,
            'Patente': d.viaje.patente_camion,
            'Conductor': d.viaje.trabajador.nombre,
            'RUT': d.viaje.trabajador.rut,
            'Tipo Peaje': d.tipo_documento,
            'Plaza/Barcaza': d.plaza_peaje,
            'Monto': d.monto,
            'N° Boleta': d.numero_documento,
            'Fecha Cruce': str(d.fecha_cruce),
            'Hora Cruce': str(d.hora_cruce),
            'Estado Viaje': d.viaje.estado,
        })
    df = pd.DataFrame(data)
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename=LASAMA_VIAJES_{datetime.now().date()}.xlsx'
    df.to_excel(response, index=False)
    return response
