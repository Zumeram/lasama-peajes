
from django.contrib import admin
from .models import Trabajador, Documento

@admin.register(Documento)
class DocumentoAdmin(admin.ModelAdmin):
    list_display = ('trabajador','tipo','monto','lugar','fecha_registro','hora_registro','numero_documento')
    list_filter = ('tipo','fecha_registro','trabajador')
    search_fields = ('trabajador__rut','lugar','numero_documento')
    readonly_fields = ('hash_imagen','fecha_registro','hora_registro')

@admin.register(Trabajador)
class TrabajadorAdmin(admin.ModelAdmin):
    list_display = ('rut','nombre')
    search_fields = ('rut','nombre')
