
from django.contrib import admin
from .models import Trabajador, Viaje, Documento
from django.utils.html import mark_safe

class DocumentoInline(admin.TabularInline):
    model = Documento
    extra = 0
    readonly_fields = ('hash_imagen',)

@admin.register(Viaje)
class ViajeAdmin(admin.ModelAdmin):
    list_display = ('codigo','origen','destino','patente_camion','trabajador','estado','total_peajes','cantidad_peajes','fecha_salida')
    list_filter = ('estado','patente_camion')
    search_fields = ('codigo','patente_camion','trabajador__rut')
    inlines = [DocumentoInline]

@admin.register(Documento)
class DocumentoAdmin(admin.ModelAdmin):
    list_display = ('viaje','tipo_documento','plaza_peaje','monto','fecha_cruce','ver_foto')
    def ver_foto(self, obj):
        if obj.imagen:
            return mark_safe(f'<a href="{obj.imagen.url}" target="_blank"><img src="{obj.imagen.url}" width="80"/></a>')
        return "-"

@admin.register(Trabajador)
class TrabajadorAdmin(admin.ModelAdmin):
    list_display = ('rut','nombre')
