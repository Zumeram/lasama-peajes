
from django.shortcuts import render
from django.http import HttpResponse
from .forms import DocumentoForm
from .models import Trabajador, Documento
import pandas as pd
from datetime import datetime
from django.db import IntegrityError

def inicio(request):
    if request.method == 'POST':
        form = DocumentoForm(request.POST, request.FILES)
        if form.is_valid():
            rut = form.cleaned_data['rut_trabajador'].strip()
            nombre = form.cleaned_data['nombre_trabajador'] or 'Conductor LASAMA'
            trabajador, _ = Trabajador.objects.get_or_create(rut=rut, defaults={'nombre': nombre})
            if nombre != 'Conductor LASAMA':
                trabajador.nombre = nombre
                trabajador.save()
            doc = form.save(commit=False)
            doc.trabajador = trabajador
            try:
                doc.save()
                return render(request, 'rendiciones/exito.html', {'doc': doc})
            except IntegrityError:
                form.add_error('imagen', '¡Peaje duplicado! Esta boleta ya fue registrada.')
    else:
        form = DocumentoForm()
    return render(request, 'rendiciones/subir.html', {'form': form})

def exportar_excel(request):
    qs = Documento.objects.select_related('trabajador').all().order_by('-fecha_ingreso')
    data = []
    for d in qs:
        data.append({
            'Empresa': 'LASAMA',
            'Nombre Conductor': d.trabajador.nombre,
            'RUT': d.trabajador.rut,
            'Patente': d.patente_camion,
            'Tipo Peaje': d.tipo_documento,
            'Plaza / Barcaza': d.plaza_peaje,
            'Monto': d.monto,
            'N° Boleta': d.numero_documento,
            'Fecha Cruce': str(d.fecha_ingreso),
            'Hora Cruce': str(d.hora_ingreso),
            'Dia': d.fecha_ingreso.strftime('%A'),
            'Registro Sistema': str(d.fecha_registro_sistema),
        })
    df = pd.DataFrame(data)
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename=LASAMA_PEAJES_{datetime.now().date()}.xlsx'
    df.to_excel(response, index=False)
    return response
