
from django.shortcuts import render
from django.http import HttpResponse
from .forms import DocumentoForm
from .models import Trabajador, Documento
import pandas as pd
from datetime import datetime
from django.db import IntegrityError

def inicio(request):
    if request.method == 'POST':
        form = DocumentoForm(request.POST, request.FILES)
        if form.is_valid():
            rut = form.cleaned_data['rut_trabajador'].strip()
            nombre = form.cleaned_data['nombre_trabajador'] or 'Trabajador LASAMA'
            trabajador, _ = Trabajador.objects.get_or_create(rut=rut, defaults={'nombre': nombre})
            if nombre != 'Trabajador LASAMA':
                trabajador.nombre = nombre
                trabajador.save()
            doc = form.save(commit=False)
            doc.trabajador = trabajador
            try:
                doc.save()
                return render(request, 'rendiciones/exito.html', {'doc': doc})
            except IntegrityError:
                form.add_error('imagen', '¡Documento duplicado! Esta imagen ya fue registrada en LASAMA.')
    else:
        form = DocumentoForm()
    return render(request, 'rendiciones/subir.html', {'form': form})

def exportar_excel(request):
    qs = Documento.objects.select_related('trabajador').all()
    data = []
    for d in qs:
        data.append({
            'RUT': d.trabajador.rut,
            'Nombre': d.trabajador.nombre,
            'Tipo': d.tipo,
            'Monto': d.monto,
            'Lugar': d.lugar,
            'N° Documento': d.numero_documento,
            'Fecha': str(d.fecha_registro),
            'Hora': str(d.hora_registro),
            'Hash': d.hash_imagen,
            'Empresa': 'LASAMA'
        })
    df = pd.DataFrame(data)
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename=LASAMA_finanzas_{datetime.now().date()}.xlsx'
    df.to_excel(response, index=False)
    return response
