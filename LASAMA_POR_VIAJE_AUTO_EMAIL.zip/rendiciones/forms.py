
from django import forms
from .models import Documento

class DocumentoForm(forms.ModelForm):
    rut_trabajador = forms.CharField(label="RUT Trabajador LASAMA", widget=forms.TextInput(attrs={'placeholder':'12.345.678-9'}))
    nombre_trabajador = forms.CharField(label="Nombre", required=False, widget=forms.TextInput(attrs={'placeholder':'Nombre completo'}))
    class Meta:
        model = Documento
        fields = ['rut_trabajador','nombre_trabajador','tipo','monto','lugar','numero_documento','imagen']
        widgets = {
            'lugar': forms.TextInput(attrs={'placeholder':'Ej: Copec Rengo, Ferreteria Lasama'}),
            'numero_documento': forms.TextInput(attrs={'placeholder':'N° Boleta/Factura si lo ves'}),
        }
