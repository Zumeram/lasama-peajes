
from django import forms
from .models import Documento
from datetime import date, datetime

class DocumentoForm(forms.ModelForm):
    rut_trabajador = forms.CharField(label="RUT Trabajador LASAMA")
    nombre_trabajador = forms.CharField(label="Nombre Trabajador", required=False)
    patente_camion = forms.CharField(label="Patente Camión", max_length=10)

    class Meta:
        model = Documento
        fields = ['rut_trabajador','nombre_trabajador','patente_camion','tipo','monto','lugar','numero_documento','fecha_ingreso','hora_ingreso','imagen']
        widgets = {
            'fecha_ingreso': forms.DateInput(attrs={'type':'date'}, format='%Y-%m-%d'),
            'hora_ingreso': forms.TimeInput(attrs={'type':'time'}),
            'lugar': forms.TextInput(attrs={'placeholder':'Ej: Copec Rengo Km 120'}),
            'numero_documento': forms.TextInput(attrs={'placeholder':'N° Boleta'}),
            'patente_camion': forms.TextInput(attrs={'placeholder':'Ej: PP-XR-45','style':'text-transform:uppercase'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['fecha_ingreso'].initial = date.today()
        self.fields['hora_ingreso'].initial = datetime.now().strftime('%H:%M')
