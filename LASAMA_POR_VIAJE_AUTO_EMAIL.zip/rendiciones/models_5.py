
from django.db import models
import hashlib

class Trabajador(models.Model):
    rut = models.CharField(max_length=12, unique=True)
    nombre = models.CharField(max_length=100)
    def __str__(self): return f"{self.nombre}"

class Viaje(models.Model):
    ESTADOS = [('En Ruta','En Ruta'),('Finalizado','Finalizado'),('Rendido','Rendido')]
    codigo = models.CharField(max_length=20, unique=True, verbose_name="N° Viaje LASAMA", help_text="Ej: V-2026-001")
    origen = models.CharField(max_length=100, verbose_name="Origen", default="Rengo")
    destino = models.CharField(max_length=100, verbose_name="Destino")
    patente_camion = models.CharField(max_length=10, verbose_name="Patente")
    trabajador = models.ForeignKey(Trabajador, on_delete=models.CASCADE, verbose_name="Conductor")
    fecha_salida = models.DateField(verbose_name="Fecha Salida")
    hora_salida = models.TimeField(verbose_name="Hora Salida")
    fecha_llegada = models.DateField(verbose_name="Fecha Llegada", blank=True, null=True)
    estado = models.CharField(max_length=15, choices=ESTADOS, default='En Ruta')
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    @property
    def total_peajes(self):
        return sum([d.monto for d in self.documentos.all()])

    @property
    def cantidad_peajes(self):
        return self.documentos.count()

    def __str__(self): return f"{self.codigo} | {self.origen}->{self.destino} | {self.patente_camion} | ${self.total_peajes}"

class Documento(models.Model):
    TIPO_PEAJE = [
        ('Peaje Troncal','Peaje Troncal'),
        ('Peaje Lateral','Peaje Lateral'),
        ('Peaje Barcaza','Barcaza / Transbordador'),
        ('Otro Peaje','Otro Peaje'),
    ]
    viaje = models.ForeignKey(Viaje, on_delete=models.CASCADE, related_name='documentos', verbose_name="Viaje LASAMA")
    tipo_documento = models.CharField(max_length=25, choices=TIPO_PEAJE, default='Peaje Troncal')
    monto = models.IntegerField(verbose_name="Monto $")
    plaza_peaje = models.CharField(max_length=100, verbose_name="Plaza / Nombre Barcaza")
    numero_documento = models.CharField(max_length=60, blank=True, verbose_name="N° Boleta")
    fecha_cruce = models.DateField(verbose_name="Fecha cruce")
    hora_cruce = models.TimeField(verbose_name="Hora cruce")
    imagen = models.ImageField(upload_to='lasama_peajes/', verbose_name="Foto Boleta")
    hash_imagen = models.CharField(max_length=64, unique=True, editable=False, blank=True)
    fecha_registro = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.imagen and not self.hash_imagen:
            hasher = hashlib.sha256()
            for chunk in self.imagen.chunks():
                hasher.update(chunk)
            self.hash_imagen = hasher.hexdigest()
        super().save(*args, **kwargs)
    def __str__(self): return f"{self.viaje.codigo} - {self.tipo_documento} {self.plaza_peaje} ${self.monto}"
