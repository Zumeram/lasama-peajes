
from django.db import models
import hashlib

class Trabajador(models.Model):
    rut = models.CharField(max_length=12, unique=True, verbose_name="RUT")
    nombre = models.CharField(max_length=100)
    def __str__(self): return f"{self.nombre} - {self.rut}"

class Documento(models.Model):
    TIPO = [('Boleta','Boleta'), ('Factura','Factura'), ('Peaje','Peaje'), ('Combustible','Combustible'), ('Otro','Otro')]

    trabajador = models.ForeignKey(Trabajador, on_delete=models.CASCADE, verbose_name="Trabajador")
    patente_camion = models.CharField(max_length=10, verbose_name="Patente Camión", help_text="Ej: AA-BB-12 o L1234")

    tipo = models.CharField(max_length=15, choices=TIPO, default='Boleta')
    monto = models.IntegerField(verbose_name="Monto $")
    lugar = models.CharField(max_length=120, verbose_name="Lugar de compra / Ruta")
    numero_documento = models.CharField(max_length=60, blank=True, verbose_name="N° Boleta/Factura")

    # Fecha, hora, dia de INGRESO - ahora manual + automatico
    fecha_ingreso = models.DateField(verbose_name="Fecha del gasto")
    hora_ingreso = models.TimeField(verbose_name="Hora del gasto")

    imagen = models.ImageField(upload_to='lasama_boletas/', verbose_name="Foto del documento")
    hash_imagen = models.CharField(max_length=64, unique=True, editable=False, blank=True)

    # Auditoría
    fecha_registro_sistema = models.DateTimeField(auto_now_add=True, verbose_name="Registrado en sistema")

    def save(self, *args, **kwargs):
        if self.imagen and not self.hash_imagen:
            hasher = hashlib.sha256()
            for chunk in self.imagen.chunks():
                hasher.update(chunk)
            self.hash_imagen = hasher.hexdigest()
        super().save(*args, **kwargs)

    def __str__(self): return f"LASAMA | {self.patente_camion} | {self.trabajador.rut} | ${self.monto}"
