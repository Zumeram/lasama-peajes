
from django.db import models
import hashlib

class Trabajador(models.Model):
    rut = models.CharField(max_length=12, unique=True, verbose_name="RUT LASAMA")
    nombre = models.CharField(max_length=100)
    def __str__(self): return f"{self.nombre} - {self.rut}"
    class Meta: verbose_name_plural = "Trabajadores LASAMA"

class Documento(models.Model):
    TIPO = [('Boleta','Boleta'), ('Factura','Factura'), ('Otro','Otro')]
    trabajador = models.ForeignKey(Trabajador, on_delete=models.CASCADE)
    tipo = models.CharField(max_length=10, choices=TIPO, default='Boleta')
    monto = models.IntegerField(verbose_name="Monto $")
    lugar = models.CharField(max_length=120)
    imagen = models.ImageField(upload_to='lasama_boletas/')
    hash_imagen = models.CharField(max_length=64, unique=True, editable=False, blank=True)
    fecha_registro = models.DateField(auto_now_add=True)
    hora_registro = models.TimeField(auto_now_add=True)
    numero_documento = models.CharField(max_length=60, blank=True, help_text="Opcional, ayuda a evitar duplicados")

    def save(self, *args, **kwargs):
        if self.imagen and not self.hash_imagen:
            hasher = hashlib.sha256()
            for chunk in self.imagen.chunks():
                hasher.update(chunk)
            self.hash_imagen = hasher.hexdigest()
        super().save(*args, **kwargs)

    def __str__(self): return f"LASAMA | {self.trabajador.rut} | {self.tipo} ${self.monto}"
