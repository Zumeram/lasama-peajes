
from django import forms
from .models import Documento
from datetime import date, datetime

class DocumentoForm(forms.ModelForm):
    rut_trabajador = forms.CharField(label="RUT Conductor")
    nombre_trabajador = forms.CharField(label="Nombre Conductor", required=False)
    class Meta:
        model = Documento
        fields = ['rut_trabajador','nombre_trabajador','patente_camion','tipo_documento','monto','plaza_peaje','numero_documento','fecha_ingreso','hora_ingreso','imagen']
        widgets = {
            'fecha_ingreso': forms.DateInput(attrs={'type':'date'}),
            'hora_ingreso': forms.TimeInput(attrs={'type':'time'}),
            'plaza_peaje': forms.TextInput(attrs={'placeholder':'Ej: Peaje Troncal Angostura, Barcaza Chacao'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['fecha_ingreso'].initial = date.today()
        self.fields['hora_ingreso'].initial = datetime.now().strftime('%H:%M')
