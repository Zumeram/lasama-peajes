
from django.db import models
import hashlib

class Trabajador(models.Model):
    rut = models.CharField(max_length=12, unique=True)
    nombre = models.CharField(max_length=100)
    def __str__(self): return f"{self.nombre} - {self.rut}"

class Documento(models.Model):
    TIPO_PEAJE = [
        ('Peaje Troncal','Peaje Troncal'),
        ('Peaje Lateral','Peaje Lateral'),
        ('Peaje Barcaza','Peaje Barcaza / Transbordador'),
        ('Peaje Troncal IDA','Peaje Troncal - IDA'),
        ('Peaje Troncal VUELTA','Peaje Troncal - VUELTA'),
        ('Otro Peaje','Otro Peaje'),
    ]

    trabajador = models.ForeignKey(Trabajador, on_delete=models.CASCADE)
    patente_camion = models.CharField(max_length=10, verbose_name="Patente Camión LASAMA")

    tipo_documento = models.CharField(max_length=25, choices=TIPO_PEAJE, default='Peaje Troncal', verbose_name="Tipo de Peaje")
    monto = models.IntegerField(verbose_name="Monto $ Peaje")
    plaza_peaje = models.CharField(max_length=100, verbose_name="Plaza / Ruta", help_text="Ej: Peaje Angostura, Troncal Maipo, Barcaza Pargua")
    numero_documento = models.CharField(max_length=60, blank=True, verbose_name="N° Boleta Peaje")

    fecha_ingreso = models.DateField(verbose_name="Fecha cruce")
    hora_ingreso = models.TimeField(verbose_name="Hora cruce")

    imagen = models.ImageField(upload_to='lasama_peajes/', verbose_name="Foto Boleta Peaje")
    hash_imagen = models.CharField(max_length=64, unique=True, editable=False, blank=True)
    fecha_registro_sistema = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.imagen and not self.hash_imagen:
            hasher = hashlib.sha256()
            for chunk in self.imagen.chunks():
                hasher.update(chunk)
            self.hash_imagen = hasher.hexdigest()
        super().save(*args, **kwargs)

    def __str__(self): return f"LASAMA {self.patente_camion} - {self.tipo_documento} - {self.plaza_peaje}"
